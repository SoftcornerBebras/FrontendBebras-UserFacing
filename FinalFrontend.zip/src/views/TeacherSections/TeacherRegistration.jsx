import React from "react";
// @material-ui/core components
import Teacher from "./TeacherRegistration/Teacher.jsx";

export default function TeacherRegistration1(props) {
  return (
    <div>
      <div style={{ marginTop: "-5%" }}>
        <br></br>
        <br></br>
        <Teacher />
      </div>
    </div>
  );
}
