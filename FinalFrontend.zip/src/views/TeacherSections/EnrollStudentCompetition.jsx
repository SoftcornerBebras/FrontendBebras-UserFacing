import React from "react";
import EnrollStudent from "./Enroll/EnrollStudent.jsx";

export default function EnrollStudentCompetition(props) {
  return (
    <div>
      <EnrollStudent />
    </div>
  );
}
