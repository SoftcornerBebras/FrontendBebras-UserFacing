import React from "react";
import BulkRegister from "./BulkRegistration/BulkRegister.jsx";

export default function BulkRegistration(props) {
  return (
    <div>
      <br></br>
      <br></br>
      <br></br>
      <br></br>
      <BulkRegister />
    </div>
  );
}
