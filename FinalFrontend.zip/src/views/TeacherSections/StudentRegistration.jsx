import React from "react";
// @material-ui/core components
import Student from "./StudenRegistration/Student.jsx";

export default function StudentRegistration1(props) {
  return (
    <div>
      <div>
        <div style={{ marginTop: "-5%" }}>
          <br />
          <br />
          <br />
          <br></br>
          <Student />
        </div>
      </div>
    </div>
  );
}
