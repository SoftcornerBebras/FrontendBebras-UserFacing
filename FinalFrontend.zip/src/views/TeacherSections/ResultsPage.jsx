import React from "react";
// nodejs library that concatenates classes

import TeacherResults from "./TeacherResult/TeacherResult.jsx";

export default function ResultsPage(props) {
  return (
    <div>
      <TeacherResults />
    </div>
  );
}
