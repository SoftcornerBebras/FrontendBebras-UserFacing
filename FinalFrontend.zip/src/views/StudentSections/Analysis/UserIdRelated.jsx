import React, { Component } from "react";

import GridContainer from "components/Grid/GridContainer.js";

var jwt = require("jsonwebtoken");

var METABASE_SITE_URL = "http://localhost:3000";
var METABASE_SECRET_KEY =
  "f4624c07c711b2ea0fb1b0e779ebdc7507161a8f0f58795746b419cedb4679c1";
var userid = JSON.parse(sessionStorage.getItem("userID"));
var payload = {
  resource: { dashboard: 1 },
  params: {
    userid: userid,
  },
  // exp: Math.round(Date.now() / 1000) + (10 * 60) // 10 minute expiration
};
var token = jwt.sign(payload, METABASE_SECRET_KEY);

var iframeUrl =
  METABASE_SITE_URL +
  "/embed/dashboard/" +
  token +
  "#bordered=false&titled=false";
class UserIdRelated extends Component {
  render() {
    return (
      <div>
        <link
          href="https://fonts.googleapis.com/css?family=Righteous&display=swap"
          rel="stylesheet"
        ></link>
        <GridContainer justify="center">
          <iframe
            title="Analysis"
            src={iframeUrl}
            frameBorder={0}
            width="95%"
            height={600}
            allowtransparency="true"
          />
        </GridContainer>
      </div>
    );
  }
}

export default UserIdRelated;
