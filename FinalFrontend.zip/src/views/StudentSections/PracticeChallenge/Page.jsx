import React from "react";
import PageSub from "./PageSection";
export var data = [];

export default function Teacher(props) {
  return (
    <div>
      <br></br>
      <br></br>

      <PageSub data={props} />
    </div>
  );
}
