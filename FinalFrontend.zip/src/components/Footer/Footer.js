/*eslint-disable*/
import React from "react";
// nodejs library to set properties for components
import PropTypes from "prop-types";
// nodejs library that concatenates classes
import classNames from "classnames";
// material-ui core components
import { List, ListItem } from "@material-ui/core";
import { makeStyles } from "@material-ui/core/styles";
import Grid from '@material-ui/core/Grid';
import Paper from '@material-ui/core/Paper';
// @material-ui/icons
import Favorite from "@material-ui/icons/Favorite";
import styles from "assets/jss/material-kit-react/components/footerStyle.js";

const useStyles = makeStyles(styles);

export default function Footer(props) {
  const classes = useStyles();
  const { whiteFont } = props;
  const footerClasses = classNames({
    [classes.footer]: true,
    [classes.footerWhiteFont]: whiteFont
  });
  const aClasses = classNames({
    [classes.a]: true,
    [classes.footerWhiteFont]: whiteFont
  });
  return (
    <div style={{}}>
      <link href="https://fonts.googleapis.com/css?family=Oswald|Special+Elite&display=swap" rel="stylesheet"></link>
      <footer className={footerClasses} style={{borderRadius: "7px", "background": "linear-gradient(0deg, rgba(2,0,36,1) 0%, rgba(4,2,37,1) 0%, rgba(16,67,101,1) 27%, rgba(31,146,179,1) 69%, rgba(128,206,215,1) 100%)" }}>
      <div className={classes.container}>
        <Grid container spacing={4}>
        <Grid item xs>
              <b><h3 style={{ fontWeight: "bolder", fontFamily: "Oswald"}}>ABOUT</h3></b>
              <p >CSpathshala  is an Association for Computing Machinery India (ACM India) initiative to bring a modern computing curriculum to Indian schools.
          </p>
        </Grid>
        <Grid item xs>
              <b><h3 style={{ fontWeight: "bolder", fontFamily: 'Oswald'}}>SCHEDULE</h3></b>
              <p >Monday - Friday: 9.00 AM - 5.00 PM<br></br>
          Saturday- Sunday: Closed</p>
        </Grid>
        <Grid item xs >
              <b><h3 style={{ fontWeight: "bolder", fontFamily: "Oswald"}}>CONTACT US</h3></b>
              <p >Address: Soft Corner, Karve Road, Pune<br></br>
Phone: +91-9678541236<br></br>
Email: softcornercummins@gmail.com
              </p>
              <br></br>
              <div style={{ "position": "absolute", "bottom": "10px" }}><marquee>&copy; {1900 + new Date().getYear()} , made with{" "}
                <Favorite className={classes.icon} /> by{" "}
            Soft Corner
          for a better web.</marquee></div>
            </Grid>
            
      </Grid>
  </div>
    </footer>
    </div>
  );
}

Footer.propTypes = {
  whiteFont: PropTypes.bool
};
